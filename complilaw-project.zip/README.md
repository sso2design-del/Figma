
  # complilaw-project

  This is a code bundle for complilaw-project. The original project is available at https://www.figma.com/design/uLN8hMLUjPOaR035FSB7BT/complilaw-project.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  